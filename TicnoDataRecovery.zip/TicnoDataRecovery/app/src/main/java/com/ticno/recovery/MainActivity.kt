package com.ticno.recovery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ticno.recovery.data.FileItem
import com.ticno.recovery.ui.components.FileRow
import com.ticno.recovery.ads.Ads
import com.ticno.recovery.ads.AdFrequencyCap

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    Ads.init(application, this)

    setContent {
      MaterialTheme {
        val vm: RecoveryViewModel = viewModel()
        val files by vm.recoverable.collectAsState()
        val scanning by vm.scanning.collectAsState()

        Scaffold(
          topBar = { TopAppBar(title = { Text("Ticno Data Recovery") }) },
          bottomBar = { Ads.Banner() }
        ) { padding ->
          Column(Modifier.padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(onClick = {
                if (AdFrequencyCap.shouldShowInterstitial("scan_click")) {
                  Ads.showInterstitial(this@MainActivity) { }
                }
                vm.scan()
              }, enabled = !scanning) {
                Text(if (scanning) "Scanning…" else "Scan Recoverables")
              }
              Button(onClick = {
                Ads.showRewarded(this@MainActivity) {
                  vm.deepScanBoost()
                }
              }) { Text("Deep Scan (Watch Ad)") }
            }
            LazyColumn(Modifier.fillMaxSize()) {
              items(files) { item ->
                FileRow(item,
                  onRestore = {
                    if (AdFrequencyCap.shouldShowInterstitial("restore_click")) {
                      Ads.showInterstitial(this@MainActivity) { vm.restore(item) }
                    } else vm.restore(item)
                  },
                  onDelete = { vm.permanentlyDelete(item) }
                )
              }
            }
          }
        }
      }
    }
  }
}
