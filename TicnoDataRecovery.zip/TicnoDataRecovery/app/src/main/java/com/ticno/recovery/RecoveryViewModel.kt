package com.ticno.recovery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ticno.recovery.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RecoveryViewModel: ViewModel() {
  private val scanner = FileScanner()
  private val recycleBin = RecycleBinStore()
  private val backups = BackupManager()

  private val _recoverable = MutableStateFlow<List<FileItem>>(emptyList())
  val recoverable = _recoverable.asStateFlow()

  private val _scanning = MutableStateFlow(false)
  val scanning = _scanning.asStateFlow()

  fun scan() {
    viewModelScope.launch {
      _scanning.value = true
      val list = scanner.scanAll()
      _recoverable.value = list
      _scanning.value = false
    }
  }

  fun deepScanBoost() {
    viewModelScope.launch {
      val list = scanner.deepScanWithBackups(backups)
      _recoverable.value = list
    }
  }

  fun restore(item: FileItem) { viewModelScope.launch { recycleBin.restore(item) } }
  fun permanentlyDelete(item: FileItem) { viewModelScope.launch { recycleBin.permanentDelete(item) } }
}
