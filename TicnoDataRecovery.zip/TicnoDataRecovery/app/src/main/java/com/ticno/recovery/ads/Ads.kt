package com.ticno.recovery.ads

import android.app.Application
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.material3.Text

object Ads {
  fun init(app: Application, ctx: Context) {
    // Initialize your chosen ad network SDK here
    // Example:
    // AppLovinSdk.getInstance(app).initializeSdk { }
    // UnityAds.initialize(app, "YOUR_GAME_ID", true)
    // StartAppSDK.init(app, "YOUR_APP_ID", true)
  }

  fun showInterstitial(ctx: Context, onClosed: ()->Unit) {
    // TODO: Implement interstitial show; call onClosed() after dismiss
    onClosed()
  }

  fun showRewarded(ctx: Context, onReward: ()->Unit) {
    // TODO: Implement rewarded; call onReward() when user earns reward
    onReward()
  }

  @Composable
  fun Banner() {
    // Placeholder composable until an SDK banner is added
    Text("Ad Banner")
  }
}
