package com.ticno.recovery.data

class RecycleBinStore {
  fun list(): List<FileItem> { return emptyList() }
  suspend fun restore(item: FileItem) { /* implement restore logic */ }
  suspend fun permanentDelete(item: FileItem) { /* implement delete logic */ }
}
