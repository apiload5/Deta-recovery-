package com.ticno.recovery.data

class FileScanner {
  suspend fun scanAll(): List<FileItem> {
    val bin = RecycleBinStore().list()
    val trash = MediaStoreTrash.query()
    val backups = BackupManager().listBackups()
    return (bin + trash + backups).distinctBy { it.id }
  }

  suspend fun deepScanWithBackups(backupManager: BackupManager): List<FileItem> {
    backupManager.reindex()
    return scanAll()
  }
}
