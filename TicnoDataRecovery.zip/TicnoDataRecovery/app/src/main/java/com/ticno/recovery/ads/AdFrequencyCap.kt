package com.ticno.recovery.ads

object AdFrequencyCap {
  private var lastShownMs: Long = 0
  private const val MIN_INTERVAL_MS = 45_000 // 45s between interstitials
  private var counter: Int = 0

  fun shouldShowInterstitial(eventKey: String): Boolean {
    val now = System.currentTimeMillis()
    if (now - lastShownMs < MIN_INTERVAL_MS) return false
    counter++
    val allow = (counter % 3 == 0) // every 3rd eligible action
    if (allow) lastShownMs = now
    return allow
  }
}
