package com.ticno.recovery.data

class BackupManager {
  fun listBackups(): List<FileItem> { return emptyList() }
  suspend fun reindex() { /* rebuild index */ }
}
