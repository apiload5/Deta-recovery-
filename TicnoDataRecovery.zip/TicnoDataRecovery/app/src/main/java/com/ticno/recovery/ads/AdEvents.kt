package com.ticno.recovery.ads

enum class AdType { INTERSTITIAL, REWARDED, BANNER }
interface AdListener {
  fun onLoaded(type: AdType) {}
  fun onShown(type: AdType) {}
  fun onClosed(type: AdType) {}
  fun onReward() {}
  fun onError(type: AdType, msg: String) {}
}
