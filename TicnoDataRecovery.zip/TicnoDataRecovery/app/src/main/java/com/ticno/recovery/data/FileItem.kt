package com.ticno.recovery.data

data class FileItem(
  val id: String,
  val displayName: String,
  val mimeType: String,
  val sizeBytes: Long,
  val deletedAt: Long?,
  val source: Source,
) {
  enum class Source { RECYCLE_BIN, MEDIASTORE_TRASH, BACKUP }
}
