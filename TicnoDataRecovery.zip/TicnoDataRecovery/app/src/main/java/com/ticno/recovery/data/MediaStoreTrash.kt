package com.ticno.recovery.data

object MediaStoreTrash {
  fun query(): List<FileItem> {
    // Device/OEM support varies; return empty for starter
    return emptyList()
  }
}
