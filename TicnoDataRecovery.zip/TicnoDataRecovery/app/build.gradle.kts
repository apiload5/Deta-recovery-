plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "com.ticno.recovery"
  compileSdk = 34

  defaultConfig {
    applicationId = "com.ticno.recovery"
    minSdk = 24
    targetSdk = 34
    versionCode = 1
    versionName = "1.0.0"
  }

  buildTypes {
    release {
      isMinifyEnabled = true
      proguardFiles(
        getDefaultProguardFile("proguard-android-optimize.txt"),
        "proguard-rules.pro"
      )
    }
    debug {
      isMinifyEnabled = false
    }
  }

  buildFeatures {
    viewBinding = true
    compose = true
  }
  composeOptions {
    kotlinCompilerExtensionVersion = "1.5.14"
  }
}

dependencies {
  implementation(platform("androidx.compose:compose-bom:2024.06.00"))
  implementation("androidx.activity:activity-compose:1.9.2")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.material3:material3:1.3.0")
  implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
  implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
  implementation("androidx.navigation:navigation-compose:2.8.0")
  implementation("com.google.accompanist:accompanist-permissions:0.36.0")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  // Add ad network SDKs here per their documentation
  // implementation("com.applovin:applovin-sdk:YOUR_VERSION")
  // implementation("com.unity3d.ads:unity-ads:YOUR_VERSION")
  // implementation("com.startapp:inapp-sdk:YOUR_VERSION")
}
