# Ticno Data Recovery (No-Root, Ads-ready)

This is a minimal Android (Kotlin + Jetpack Compose) starter project for a policy-safe data recovery style app.
It focuses on in-app recycle bin, best-effort MediaStore trash checks, and user-consented backups. No rooting features.

## Ads
Wire any one ad SDK in `com.ticno.recovery.ads.Ads` and add its Gradle dependency.

## Build
Open in Android Studio (Giraffe+), let Gradle sync, then Run.
